const express = require('express');
const mysql = require('mysql');
const cors = require('cors')
const db = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "password",
    database: "pettool",
  });

const app = express();
app.use(cors())
app.use(express.json())
app.listen(3023, () => {
  console.log(" Server operational");
})

const bcrypt = require ('bcrypt');// bcrypt
const { response } = require('express');
const saltRounds = 10// data processing time
const Password= "123456";

const password =bcrypt.hashSync(Password, saltRounds) ;



app.post("/create", (req, res) => {
  const first = req.body.firstName;
  const last = req.body.lastName;
  const Age = req.body.userAge;
  const Phonenumber = req.body.userPhonenumber;
  const Email = req.body.userEmail;
  const password =bcrypt.hashSync(req.body.userPassword, 10) ;
  try{
  db.query("INSERT INTO user(firstName,lastName,userPhoneNumber,userEmail,userAge,password) VALUES (?,?,?,?,?,?)" ,
  [first,last,Phonenumber,Email,Age,password] , (err,result )=>{
      if (err){
          res.send("Email Already Registered")
      }else {
          res.send("Values Inserted")
      }
  }
   )}catch(err){console.log(err)}
})

//---------------------------------------------------------------------------------------------------
//Log in 
/*
app.post("/checkLog",(req,res) =>{
  const email = req.body.userEmail ;
  const password = req.body.userPassword;
  db.query("SELECT password FROM user where userEmail = ?" , [email], (err, result) => {
    if (err) {
      console.log(err);
    } else {if( bcrypt.compare(password, result)){
      db.query("INSERT INTO loggedIn(userID) VALUES(SELECT userID FROM user WHERE userEmail = ?", [email]);
      res.send("YOOOOO")
    }else{res.send(Boolean = false)}
    app.post("/checkLog",(req,res) =>{
  const email = req.body.userEmail ;
  const password = req.body.userPassword
  db.query(" SELECT * FROM user WHERE userEmail =? AND password = ? ", [email,password], (err,result)=>
  {if (err) {
    console.log(err);
  } else {
    console.log(result)
  res.send(result)
}
  }
  )
  }
)

app.post("/checkLog",(req,res) =>{
  const useremail = req.body.userEmail ;
  db.query(" SELECT * FROM user WHERE userEmail =? ", useremail, (err,result)=>
  {if (err) {
    console.log(err);
  } else {
    console.log(result)
  res.send(result)
}
  }
  )
  }
)*/
app.post("/checkLog",(req,res) =>{
  const useremail = req.body.userEmail 
  const password= req.body.password
  db.query(" SELECT * FROM user WHERE userEmail =? AND password=?  ", [useremail,password], (err,result)=>
  {if (err) {
    console.log(err);
  } else 
    if(result){ console.log(result)
    console.log(result)
  res.send(result)}else{
        res.send("Wrong combination or not registered")
  }
})}
  
)
app.post("/checkLogB",(req,res) =>{
  const useremail = req.body.userEmail 
  const password= req.body.password
  db.query(" SELECT * FROM user WHERE userEmail =? ", [useremail], (err,result)=>
  { if (err) {
    console.log(err);
  } else { bcrypt.compare(password, result[0].password, function(error, isMatch) {
    if(isMatch){
      console.log("@222222")
      console.log(result)
      res.send(result)}

    
    }
  )
}
  }
  )
})





  
   

  

//----------------------------------------------------------------------
//user


app.get("/allUsers", (req, res) => {
  db.query("SELECT * FROM user", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  });
});

app.post("/usersByID", (req, res) => {
  const userID = req.body.userID ;
  db.query("SELECT * FROM user WHERE userID = ?", userID ,function (err, result) { 
      if (err) {
        console.log(err);
      } else {
        res.send(result);
      }
    });
});

//------------------------------------------------------------------------
//Pets
app.get("/allpets", (req, res) => {
  db.query("SELECT * FROM pet", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  });
});

app.post("/petByOwner", (req, res) => {
  const userID = req.body.userID;
  db.query("SELECT * FROM PET WHERE userID = ? ", userID,(err, result) => {
   
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  
})});

app.post("/petByBreeder", (req,res)=> {
  const breederID = req.body.breederID

  db.query("SELECT * FROM PET WHERE breedcenterID =?", breederID, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})

app.post("/petByShelter", (req,res)=> {
  const shelterID = req.body.shelterID

  db.query("SELECT * FROM PET WHERE petID = (SELECT petID FROM IS_IN_SHELTER WHERE shelterID) = ?", shelterID, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }

  })


})







app.post("/petByBreed", (req,res)=> {
  const petBreed = req.body.petBreed

  db.query("SELECT * FROM PET WHERE petBreed =?", petBreed, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})

app.post("/petByGender", (req,res)=> {
  const petGender = req.body.petGender

  db.query("SELECT * FROM PET WHERE petGender =?", petGender, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})

app.post("/petByName", (req,res)=> {
  const petName = req.body.petName

  db.query("SELECT * FROM PET WHERE petName =?", petName, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})
//------------------------------------------------------------------------------------
app.get("/allshelters", (req,res)=> {

  db.query("SELECT * FROM SHELTER", (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})

app.post("/shelterByID", (req,res)=> {
  const shelterID = req.body.shelterID

  db.query("SELECT * FROM SHELTER WHERE shelterID =?", shelterID, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})


app.post("/shelterByGovernorate", (req,res)=> {
  const shelterGovernorate = req.body.shelterGovernorate

  db.query("SELECT * FROM SHELTER WHERE shelterGovernorate =?", shelterGovernorate, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})
  
app.post("/shelterByMunicipality", (req,res)=> {
    const shelterMunicipality = req.body.shelterMunicipality
  
    db.query("SELECT * FROM SHELTER WHERE shelterMunicipality =?", shelterMunicipality, (err,result)=>{
      if (err) {
        console.log(err);
      } else {
        console.log(result);
        res.send(result);
      }
  
    })


})

app.post("/shelterByGovernorateMunicipality", (req,res)=> {
   const shelterMunicipality = req.body.shelterMunicipality
   const shelterGovernorate = req.body.shelterGovernorate
  db.query("SELECT * FROM SHELTER WHERE shelterMunicipality =? AND shelterGovernorate =?", [shelterMunicipality, shelterGovernorate], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})


app.post("/shelterByName", (req,res)=> {
  const shelterName = req.body.shelterName 

  db.query("SELECT * FROM SHELTER WHERE shelterName LIKE ?", shelterName + '%', (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})
//--------------------------------------------------------------------------------------------
//Breed
app.get("/allbreedcenter", (req,res)=> {

  db.query("SELECT * FROM BREEDCENTER", (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})


app.post("/shelterByID", (req,res)=> {
  const shelterID = req.body.shelterID

  db.query("SELECT * FROM SHELTER WHERE shelterID =?", shelterID, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})


app.post("/breedcenterByGovernorate", (req,res)=> {
  const breedCenterGovernorate = req.body.breedCenterGovernorate

  db.query("SELECT * FROM BREEDCENTER WHERE breedCenterGovernorate =?", breedCenterGovernorate, (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }
    
  })
})
app.post("/breedcenterByGovernorateSearch", (req,res)=> {
  const breedCenterGovernorate = req.body.breedCenterGovernorate 

  db.query("SELECT * FROM BREEDCENTER WHERE breedCentergovernorate LIKE  ?", '%' + breedCenterGovernorate + '%', (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})
app.post("/breedcenterByMunicipalitySearch", (req,res)=> {
  const breedCenterMunicipality = req.body.breedCenterMunicipality

  db.query("SELECT * FROM BREEDCENTER WHERE breedCentermunicipaility LIKE  ?", '%' + breedCenterMunicipality + '%', (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})

  
app.post("/breedcenterByMunicipality", (req,res)=> {
    const breedCenterMunicipality = req.body.breedCenterMunicipality
  
    db.query("SELECT * FROM BREEDCENTER WHERE breedCentermunicipaility =?", breedCenterMunicipality, (err,result)=>{
      if (err) {
        console.log(err);
      } else {
        console.log(result);
        res.send(result);
      }
  
    })


})

app.post("/breedcenterByGovernorateMunicipality", (req,res)=> {
   const breedCenterMunicipality = req.body.breedCenterMunicipality
   const breedCenterGovernorate = req.body.breedCenterGovernorate
  db.query("SELECT * FROM BREEDCENTER WHERE breedCentermunicipaility =? AND breedcenterGovernorate =?", 
  [breedCenterMunicipality, breedCenterGovernorate], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})
app.post("/breedcenterByGovernorateMunicipalitySearch", (req,res)=> {
   const breedCenterMunicipality = req.body.breedCenterMunicipality
   const breedCenterGovernorate = req.body.breedCenterGovernorate
  db.query("SELECT * FROM BREEDCENTER WHERE breedCentermunicipaility LIKE "%"+ ? +"%" AND breedcentergovernorate LIKE "%"+ ? +"%"", 
  [breedCenterMunicipality, breedCenterGovernorate], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })


})




app.post("/breedcenterByName", (req,res)=> {
  const breedcenterName = req.body.breedcenterName 

  db.query("SELECT * FROM BREEDCENTER WHERE breedcenterName LIKE ?", breedcenterName + '%', (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log(result);
      res.send(result);
    }

  })
})

app.post("/updateAvg", (req,res)=> {
  const breedCenterID = req.body.breedCenterID 

  db.query("UPDATE BREEDCENTER SET averagePrice = (SELECT AVG(price) FROM PET WHERE breedCenterID =?) WHERE breedCenterID =?"
  , [breedCenterID, breedCenterID], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log("Updated");
    }

  })
})
//----------------------------------------------------------------------------------
app.post("/adoptionApp", (req,res)=> {
  const shelterID = req.body.shelterID 
  const petID = req.body.petID
  const userID = req.body.userID
  const currentDate = req.body.fullDate
  db.query("INSERT INTO APPLIES_TO_ADOPT VALUES(?,?,?,?) "
  , [userID, petID,shelterID,currentDate], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log("Application sent");
    }

  })
})

//--------------------------------------------------------------------------------------
app.post("/buyApp", (req,res)=> {
  const breedCenterID = req.body.breedCenterID 
  const petID = req.body.petID
  const userID = req.body.userID
  const date =req.body.date
  const status =req.body.status
  db.query("INSERT INTO APPLIES_TO_BUY VALUES(?,?,?,?,?)"
  , [userID,petID,breedCenterID,date,status], (err,result)=>{
    if (err) {
      console.log(err);
    } else {
      console.log("Application sent");
    }

  })
})
//------------------------------------------------------
app.post("/getTraining", (req,res)=> {
  db.query("SELECT * FROM TRAINING_SERVICE" , (err,result)=>{
    if (err) {
      console.log(err);
    } else {
     res.send(result);
    }

  })
})
app.post("/addTraining", (req,res)=> {
  const userID = req.body.userID
  const serviceID = req.body.serviceID
  const date = req.body.partDate
  db.query("INSERT INTO REGISTERS VALUES(?,?,?)",[userID,serviceID,date] , (err,result)=>{
    if (err) {
      console.log(err);
    } else {
     res.send("Registered");
    }

  })
})
app.post("/addRatingTrainer", (req,res)=> {
  const serviceID= req.body.serviceID
  const userID = req.body.userID
  const serviceRating = req.body.rating
  const date = req.body.fullDate 
  db.query("INSERT INTO SERVICERATING VALUES(?,?,?,?) " ,[serviceID,userID,serviceRating,date], (err,result)=>{
    if (err) {
      console.log(date)
      console.log(err);
    } else {
     res.send("DONZO");
}})})

app.post("/getAverageRateTrainer", (req,res)=> {
  const serviceID= req.body.serviceID
  db.query("SELECT AVG(serviceRating) AS rate FROM SERVICERATING WHERE serviceID =?",serviceID, (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})

//-------------------------------------------------------------------------------------
app.post("/addRatingBreeder", (req,res)=> {
  const breedCenterID= req.body.breedCenterID
  const userID = req.body.userID
  const rating = req.body.rating
  const date = req.body.fullDate 
  db.query("INSERT INTO BREEDCENTERRATING VALUES(?,?,?,?) " ,[breedCenterID,userID,rating,date], (err,result)=>{
    if (err) {
      console.log(date)
      console.log(err);
    } else {
     res.send("DONZO");
}})})

app.post("/getAverageRates", (req,res)=> {
  const breedCenterID= req.body.breedCenterID
  db.query("SELECT B.*, AVG(breedCenterRating) AS rate FROM BREEDCENTERRATING B , BREEDCENTERRATING BR WHERE breedCenterID =?",breedCenterID, (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})

app.post("/getAverageRate", (req,res)=> {
  const breedCenterID= req.body.breedCenterID
  db.query("SELECT AVG(breedCenterRating) AS rate FROM BREEDCENTERRATING WHERE breedCenterID =?",breedCenterID, (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})

app.post("/donate", (req,res)=> {
  const shelterID= req.body.shelterID
  const amount = req.body.amount
  const date = req.body.fullDate
  const userID = req.body.userID
  db.query("INSERT INTO DONATES VALUES (?,?,?,?)",[userID,shelterID,amount,date], (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send("Good for you");
}})})

app.post("/getDonate", (req,res)=> {
  const userID = req.body.userID
  db.query("SELECT S.shelterName, D.amount, D.donationDate FROM DONATES D, SHELTER S WHERE D.shelterID = S.shelterID AND userID =? ORDER BY donationDate DESC",userID, (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})

app.post("/getDonate", (req,res)=> {
  const userID = req.body.userID
  db.query("SELECT S.shelterName, D.amount, D.donationDate FROM DONATES D, SHELTER S WHERE D.shelterID = S.shelterID AND userID =? ORDER BY donationDate DESC",userID, (err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})

//---------------------------------------------------------------------
app.post("/appAccept", (req,res)=> {
  const userID = req.body.userID
  const petID = req.body.petID
  db.query("UPDATE PET SET breedCenterID = NULL, userID = ? WHERE petID = ?",[userID,petID],(err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})
app.post("/appUpdateAccept", (req,res)=> {
  const userID = req.body.userID
  const petID = req.body.petID

  db.query("UPDATE APPLIES_TO_BUY SET status = 'accepted' WHERE userID = ? AND petID =?",[userID,petID],(err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})
app.post("/appUpdateRejected", (req,res)=> {
  const userID = req.body.userID
  const petID = req.body.petID

  db.query("UPDATE APPLIES_TO_BUY SET status = 'rejected' WHERE userID = ? AND petID =? ",[userID,petID],(err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})
app.post("/appGet", (req,res)=> {
  const userID = req.body.userID

  db.query("SELECT P.*, A.* FROM PET P, APPLIES_TO_BUY A WHERE A.petID = P.petID AND A.userID = ? AND status = 'pending'",userID,(err,result)=>{
    if (err) {      
      console.log(err);
    } else {
     res.send(result);
}})})


 




